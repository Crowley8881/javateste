var num = parseInt(prompt("Informe um número: ", ""));
var num2 = parseInt(prompt("Informe um número: ", ""));
