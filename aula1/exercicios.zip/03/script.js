var dia = parseInt(prompt("Informe um dia ", ""));
var mes = parseInt(prompt("Informe um mes", ""));
var ano = parseInt(prompt("Informe um ano",""))

 if(ano == 2025) alert("O data possivel" + dia+ mes +ano);
 else alert("data impossivel")

